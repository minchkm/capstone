package com.example.capstone;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class GoogleSignInActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activiti_login); // 레이아웃 파일명에 맞게!
    }
}

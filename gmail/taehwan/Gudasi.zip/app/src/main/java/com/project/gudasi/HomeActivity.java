package com.project.gudasi; // ← 앱 패키지에 맞게 수정

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private SubscriptionAdapter adapter;
    private List<Subscription> subscriptionList = new ArrayList<>();
    private FirebaseFirestore firedb;
    private TextView totalSubscriptionAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home); // 현재 액티비티 레이아웃

        totalSubscriptionAmount = findViewById(R.id.totalSubscriptionAmount);

        FirebaseApp.initializeApp(this);
        firedb = FirebaseFirestore.getInstance();

        DBHelper dbHelper = new DBHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM user", null);

        if (cursor != null && cursor.moveToFirst()) {
            int nameIndex = cursor.getColumnIndex("name");

            if (nameIndex != -1) {
                String name = cursor.getString(nameIndex); // DB에서 직접 가져오기

                TextView userName = findViewById(R.id.userName);
                userName.setText(name + "님");
            } else {
                Log.e("DB_ERROR", "컬럼 인덱스를 찾을 수 없습니다.");
            }
        } else {
            Toast.makeText(this, "사용자 정보가 없습니다.", Toast.LENGTH_SHORT).show();
        }

        if (cursor != null) cursor.close();
        db.close();

        recyclerView = findViewById(R.id.subscriptionRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SubscriptionAdapter(subscriptionList);
        recyclerView.setAdapter(adapter);



        FirebaseApp.initializeApp(this);
        recyclerView = findViewById(R.id.subscriptionRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new SubscriptionAdapter(subscriptionList);
        recyclerView.setAdapter(adapter);

        // 구독 데이터 Firestore에서 로드
        loadSubscriptions();

        // 하단 메뉴 버튼 처리
        setupBottomNavigation();


    }

    private void setupBottomNavigation() {
        // 하단 메뉴 버튼들 참조
        ImageView btnHome = findViewById(R.id.btnHome);
        ImageView btnRanking = findViewById(R.id.btnRanking);  // 수정: 래퍼 LinearLayout에도 ID 추가
        ImageView btnAppUsage = findViewById(R.id.btnAppUsage);
        ImageView btnMyPage = findViewById(R.id.btnMyPage);

        btnHome.setOnClickListener(v -> {
            // 현재 페이지와 동일하므로 새로 열 필요 없음
        });

        btnRanking.setOnClickListener(v -> {
            startActivity(new Intent(HomeActivity.this, RankingActivity.class));
        });

        btnAppUsage.setOnClickListener(v -> {
            startActivity(new Intent(HomeActivity.this, UsageStatsActivity.class));
        });

        btnMyPage.setOnClickListener(v -> {
            startActivity(new Intent(HomeActivity.this, ProfileActivity.class));
        });

    }

    private void loadSubscriptions() {
        firedb.collection("subscriptions")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        subscriptionList.clear();
                        int totalPrice = 0;

                        for (QueryDocumentSnapshot doc : task.getResult()) {
                            Subscription s = doc.toObject(Subscription.class);
                            subscriptionList.add(s);

                            // 가격 문자열에서 숫자만 추출
                            String priceStr = s.getRenewalPrice(); // renewalPrice 필드가 String이라고 가정
                            int price = parsePriceString(priceStr);
                            totalPrice += price;
                        }

                        adapter.notifyDataSetChanged();

                        totalSubscriptionAmount.setText("₩" + String.format("%,d", totalPrice));
                    }
                });
    }

    // 가격 문자열에서 숫자만 추출하는 유틸 함수
    private int parsePriceString(String priceStr) {
        if (priceStr == null) return 0;

        // 예: "₩19,500/1개월" -> "/" 앞부분만 취함
        String[] parts = priceStr.split("/");
        String pricePart = parts[0];  // "₩19,500"

        // 숫자만 추출
        String numOnly = pricePart.replaceAll("[^0-9]", "");
        if (numOnly.isEmpty()) return 0;

        try {
            return Integer.parseInt(numOnly);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return 0;
        }
    }
}
